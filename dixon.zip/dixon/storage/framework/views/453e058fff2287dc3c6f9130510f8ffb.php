

<?php $__env->startSection('admin'); ?>

    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
            integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>

    <style>
    body{
        background: #eef5fe;
    }
    </style>

    <div class="container" align="center" style="margin-top:100px;">
        <h2 style="margin-bottom:-90px;"><u>View Users</u></h2>


        <table class="table table-bordered">
            <thead>
                <tr>
                    <th align="center">Id</th>
                    <th align="center">User Name</th>
                    <th align="center">Email</th>
                    <th align="center">Type</th>

                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align="center"><?php echo e($item->id); ?></td>
                        <td align="center"><?php echo e($item->name); ?></td>
                        <td align="center"><?php echo e($item->email); ?></td>
                        <td align="center"><?php echo e($item->type); ?></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dixon\dixon\resources\views/admin/index.blade.php ENDPATH**/ ?>