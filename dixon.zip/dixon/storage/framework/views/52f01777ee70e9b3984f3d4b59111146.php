

<?php $__env->startSection('forum'); ?>
    <div class="card" style="margin:20px;">
        <div class="card-header">Edit Post</div>
        <div class="card-body">

            <form action="<?php echo e(url('forumPage/' .$posts->id)); ?>" method="post">
                <?php echo csrf_field(); ?>

                <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="id" id="id" value="<?php echo e($posts->id); ?>" id="id" />
                <label>Name</label><br>
                <input type="text" name="name" id="name" value="<?php echo e($posts->name); ?>" class="form-control">
                <label>Description</label><br>
                <input type="text" name="description" id="description" value="<?php echo e($posts->description); ?>"
                    class="form-control">
                <label>Image</label><br>
                <input type="text" name="image" id="image" value="<?php echo e($posts->image); ?>" class="form-control">
                <input type="submit" value="Update" class="btn btn-success"><br>
            </form>

        </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dixon\dixon\resources\views/edit.blade.php ENDPATH**/ ?>