



<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Approve Page</title>
</head>

<?php $__env->startSection('admin'); ?>
    <br>
    <div class="container">
        <center>
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th width="200px;"><br><a href="<?php echo e(route('approvePage')); ?>"><center>Approve Post</center></a><br></th>
                    </tr>
                    <tr><td style="background-color:#eef5fe;"></td></tr>
                    <tr>
                        <th width="200px;"><br><a href="<?php echo e(route('approvePage')); ?>"><center>Decline Post</center></a><br></th>
                    </tr>
                    <tr><td style="background-color:#eef5fe;"></td></tr>
                    
                    <tr>
                        <th width="200px;"><br><a href="<?php echo e(route('approvePage')); ?>"><center>Approved Post</center></a><br></th>
                    </tr>
                </thead>
            </table>
        </div>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dixon\dixon\resources\views/manageForum.blade.php ENDPATH**/ ?>