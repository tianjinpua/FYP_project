

<?php $__env->startSection('admin'); ?>
    <div class="card mt-4" align="center" style="margin:120px;">
        <div class="card-header">
            <h2 style="margin-bottom:-90px;"><u>Create New Category</u></h2>
        </div>
        <div class="card-body">
            <a href="<?php echo e(url('admin/categories/create')); ?>" class="btn btn-success btn-sm" title="Add New Category"><button>
                    Add New</button>
            </a>

            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th align="center"><u>Id</u></th>
                            <th align="center"><u>Name</u></th>
                            <th align="center"></th>
                            <th align="center"></th>
                            <th align="center"><u>Edit</u></th>
                            <th align="center"><u>Delete</u></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            </tr>
                            <tr>
                            </tr>
                            <tr>
                            </tr>
                            <tr>
                                <td align="center"><?php echo e($loop->iteration); ?></td>
                                <td align="center"><?php echo e($new->name); ?></td>
                                <td></td>
                                <td></td>
                                <td align="center">
                                    <a href="<?php echo e(url('/admin/categories/' . $new->id . '/edit')); ?>" title="Edit Post"><button
                                            class="btn btn-primary btn-sm">Edit</button></a>
                                </td>
                                <td align="center">

                                    <form method="POST" action="<?php echo e(url('/admin/categories' . '/' . $new->id)); ?>"
                                        accept-charset="UTF-8" style="display:inline">
                                        <?php echo e(method_field('DELETE')); ?>

                                        <?php echo e(csrf_field()); ?>

                                        <button type="submit" class="btn-danger btn-sm" title="Delete Post"
                                            onclick="return confirm("Confirm delete?")">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dixon\dixon\resources\views/admin/categories.blade.php ENDPATH**/ ?>