

<?php $__env->startSection('forum'); ?>
    <div class="card" style="margin:20px;">
        <div class="card-header">Edit User</div>
        <div class="card-body">
            <form action="<?php echo e(url('admin/users')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="id" id="id" value="<?php echo e($users->id); ?>" id="id" />
                <label>Role</label><br>
                <input type="text" name="type" id="type" value="<?php echo e($users->type); ?>" class="form-control">

                <input type="submit" value="Update" class="btn btn-success"><br>
            </form>

        </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dixon\dixon\resources\views/admin/edit.blade.php ENDPATH**/ ?>