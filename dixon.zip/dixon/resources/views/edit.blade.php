@extends('layouts.nav')

@section('forum')
    <div class="card" style="margin:20px;">
        <div class="card-header">Edit Post</div>
        <div class="card-body">

            <form action="{{url('forumPage/' .$posts->id)}}" method="post">
                {!! csrf_field() !!}
                @method('PATCH')
                <input type="hidden" name="id" id="id" value="{{ $posts->id }}" id="id" />
                <label>Name</label><br>
                <input type="text" name="name" id="name" value="{{ $posts->name }}" class="form-control">
                <label>Description</label><br>
                <input type="text" name="description" id="description" value="{{ $posts->description }}"
                    class="form-control">
                <label>Image</label><br>
                <input type="text" name="image" id="image" value="{{ $posts->image }}" class="form-control">
                <input type="submit" value="Update" class="btn btn-success"><br>
            </form>

        </div>

    @stop
